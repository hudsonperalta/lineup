angular.module('lineupApp', ['ng-sortable'])
    .controller('lineup', ['$scope', function ($scope) {
        $scope.player = [
            { name: 'A', number: '8' },
            { name: 'B', number: '10' },
            { name: 'C', number: '18' },
            { name: 'D', number: '2' },
            { name: 'E', number: '3' },
            { name: 'F', number: '7' },
            { name: 'G', number: '9' },
            { name: 'H', number: '4' },
            { name: 'I', number: '44' },
            { name: 'J', number: '24' },
            { name: 'K', number: '28' }
        ];
        $scope.playerConfig = { animation: 150 };
        
        $scope.spots = 10;
        $scope.getSpots = function (num) {
            return new Array(num);   
        }
        
        $scope.positions = [
            { pos: 'P', posNum: '1' },
            { pos: 'C', posNum: '2' },
            { pos: '1B', posNum: '3' },
            { pos: '2B', posNum: '4' },
            { pos: '3B', posNum: '5' },
            { pos: 'SS', posNum: '6' },
            { pos: 'LF', posNum: '7' },
            { pos: 'CF', posNum: '8' },
            { pos: 'RF', posNum: '9' },
            { pos: 'EH', posNum: '10' }
        ];
        
//        $scope.focus = false;
//        $scope.toggleFocus = function() {
//            $scope.focus = $scope.focus === true ? false: true;
//        };
        
//        $scope.togglePos = function($event, className) {
//            var scope = this;
//                className = className || 'is-open';
//                $($event.target).toggleClass(className);
//        }

    }])

posOpen = 0;
var posSelected = [];
var allPositions = [1,2,3,4,5,6,7,8,9,10];
var removeItem = '';

function drawPos(){
    $('#all').text(allPositions)
    $('#sel').text(posSelected)
}

drawPos();

function openPos() {
    if(posOpen == 0) {
        posOpen = 1;
        $('#posOptions').addClass('open');
    }
    //else closePos();
}

function closePos() {
    posOpen = 1;
    $('#posOptions').removeClass('open');
}

function remFocus() {
    $('#pos li[data-selection]').attr('data-selection','');
    //alert(posOpen);
}

$(document).on('click', '#pos li', function() {
    remFocus();
    openPos();
    $(this).attr('data-selection','focus');
});

$(document).on('click', '#posOptions li', function() {
    var $pos = $(this);
    var thisPos = $pos.attr('data-pos');
    var thisPosNum = $pos.attr('data-pos-number');
    var $setPos = $('#pos li[data-selection="focus"]');
    var setPosNum = $setPos.attr('data-set-pos');
    
    var removeItem = setPosNum; 

    if($.inArray(thisPosNum, posSelected) !== -1){

        $('[data-set-pos='+thisPosNum+']').text('').attr('data-set-pos','');
        $setPos.text(thisPos).attr('data-set-pos',thisPosNum);
    }
    else {
        $pos.addClass('used');
        $setPos.text(thisPos).attr('data-set-pos',thisPosNum);
    }
    
    posSelected.push(thisPosNum);
    
    drawPos();

    //alert(posSelected)
});


        
//  allPositions = jQuery.grep(allPositions, function(value) {
//      return value != removeItem;
//  });




