angular.module('lineupApp', ['ng-sortable'])
    .controller('lineup', ['$scope', function ($scope) {
        $scope.player = [
            { name: 'A', number: '8' },
            { name: 'B', number: '10' },
            { name: 'C', number: '18' },
            { name: 'D', number: '2' },
            { name: 'E', number: '3' },
            { name: 'F', number: '7' },
            { name: 'G', number: '9' },
            { name: 'H', number: '4' },
            { name: 'I', number: '44' },
            { name: 'J', number: '24' },
            { name: 'K', number: '28' }
        ];
        $scope.playerConfig = { animation: 150 };
        
        $scope.spots = 10;
        $scope.getSpots = function (num) {
            return new Array(num);   
        }
        
        $scope.positions = [
            { pos: 'P', posNum: '1' },
            { pos: 'C', posNum: '2' },
            { pos: '1B', posNum: '3' },
            { pos: '2B', posNum: '4' },
            { pos: '3B', posNum: '5' },
            { pos: 'SS', posNum: '6' },
            { pos: 'LF', posNum: '7' },
            { pos: 'CF', posNum: '8' },
            { pos: 'RF', posNum: '9' },
            { pos: 'EH', posNum: '10' }
        ];
        
//        $scope.focus = false;
//        $scope.toggleFocus = function() {
//            $scope.focus = $scope.focus === true ? false: true;
//        };
        
//        $scope.togglePos = function($event, className) {
//            var scope = this;
//                className = className || 'is-open';
//                $($event.target).toggleClass(className);
//        }

    }])

function remFocus() {
    $('#pos li.focus').removeClass('focus');
}

$(document).on('click', '#pos li', function() {
    remFocus();
    $(this).addClass('focus');
});